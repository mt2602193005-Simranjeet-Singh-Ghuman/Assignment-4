# Question 7.
# Which ISBNs are in metadata, but have no matching file
# in coverpage, blurb, or review?

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def show_gap(report, source_name, kind, missing):
    # Print the count and a short sample. The full list goes into a text file.
    report.say("  no " + kind + " file: " + str(len(missing)))
    filename = source_name + "_missing_" + kind + ".txt"
    report.save_lines(filename, missing)
    if len(missing) == 0:
        return
    sample = ", ".join(missing[:8])
    report.say("    sample: " + sample)
    report.say("    full list: " + filename)


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 7. Metadata ISBNs with no cover, blurb, or review file")
    report.say("")
    report.say("I start from the ISBNs in metadata. A book is missing a piece")
    report.say("when that folder has no file whose name begins with that ISBN.")
    report.say("Several review files for one ISBN still count as having a review.")
    report.say("")

    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        metadata_isbns = set(records.keys())
        report.say(source["name"] + " metadata ISBNs: " + str(len(metadata_isbns)))

        for kind in ("coverpage", "blurb", "review"):
            names = bookdata.list_files(source, kind)
            by_isbn, _broken = bookdata.index_files(names)
            have_file = set(by_isbn.keys())
            missing = sorted(metadata_isbns - have_file)  # in the JSON, not in this folder
            show_gap(report, source["name"], kind, missing)
        report.say("")

    report.save()


if __name__ == "__main__":
    main()
