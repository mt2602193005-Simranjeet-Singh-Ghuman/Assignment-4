# Question 6.
# Which metadata fields are missing from the JSON itself,
# as opposed to fields that exist but are sometimes empty?
# Cover, blurb, and review are files, so they are not metadata fields.

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 6. Fields absent from the metadata JSON")
    report.say("")
    report.say("A field-level gap means the key is not in the JSON at all.")
    report.say("A value-level gap means the key is there, but the value is blank or N/A.")
    report.say("Cover page, blurb, and review are files. I do not treat them as JSON fields.")
    report.say("")

    schemas = {}
    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        total = len(records)

        ever = set()  # keys that appear on at least one record
        always = None  # keys that appear on every record
        empty_counts = {}

        for record in records.values():
            keys = set(record.keys())
            ever.update(keys)
            if always is None:
                always = set(keys)
            else:
                always = always & keys  # keep only keys seen on every record so far

            for key, value in record.items():
                if key not in empty_counts:
                    empty_counts[key] = 0
                if bookdata.is_missing(value):
                    empty_counts[key] += 1

        schemas[source["name"]] = ever
        sometimes = sorted(ever - always)  # present on some records, absent on others
        always_empty = []
        for key in sorted(ever):
            if empty_counts.get(key, 0) == total:  # every record has this key, and every value is empty
                always_empty.append(key)

        report.say(source["name"])
        report.say("  keys present: " + ", ".join(sorted(ever)))
        if len(sometimes) == 0:
            report.say("  No key is missing from some records and present on others.")
        else:
            report.say("  Keys missing from some records: " + ", ".join(sometimes))
        if len(always_empty) == 0:
            report.say("  No field is empty on every record.")
        else:
            report.say("  Field exists, but every value is empty: " + ", ".join(always_empty))
        report.say("")

    # A key that one website has and another website never has is a real field-level gap.
    all_names = list(schemas.keys())
    union_keys = set()
    for keys in schemas.values():
        union_keys.update(keys)

    report.say("Compared across the three sources:")
    found_gap = False
    for name in all_names:
        absent = sorted(union_keys - schemas[name])
        if len(absent) == 0:
            report.say("  " + name + " has every key that the other sources have.")
        else:
            found_gap = True
            report.say("  " + name + " is missing these keys entirely: " + ", ".join(absent))

    report.say("")
    if not found_gap:
        report.say("No field is structurally absent. The same 19 keys are in every record.")
        report.say("origin_country is the closest case to the example in the question.")
        report.say("The key is present, but Goodreads and OpenLibrary store N/A for every book.")
        report.say("That is a value-level gap, not a missing key.")
        report.say("OpenLibrary language, format, series, edition, price, rating, and ratings_count are the same kind of gap.")

    report.save()


if __name__ == "__main__":
    main()
