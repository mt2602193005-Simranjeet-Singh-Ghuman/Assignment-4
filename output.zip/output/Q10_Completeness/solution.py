# Question 10.
# How many books have metadata, a cover, a blurb, and a review,
# and how many are only partly covered?

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def file_isbns(source, kind):
    # The set of ISBNs that have at least one file of this kind.
    names = bookdata.list_files(source, kind)
    by_isbn, _broken = bookdata.index_files(names)
    return set(by_isbn.keys())


def describe(report, title, isbns, covers, blurbs, reviews, metadata):
    # Count books by how many of the four pieces they have.
    all_four = 0
    only_three = 0
    only_two = 0
    only_one = 0
    none = 0
    missing_cover = 0
    missing_blurb = 0
    missing_review = 0
    missing_metadata = 0

    for isbn in isbns:
        has_meta = isbn in metadata
        has_cover = isbn in covers
        has_blurb = isbn in blurbs
        has_review = isbn in reviews
        pieces = 0
        if has_meta:
            pieces += 1
        else:
            missing_metadata += 1
        if has_cover:
            pieces += 1
        else:
            missing_cover += 1
        if has_blurb:
            pieces += 1
        else:
            missing_blurb += 1
        if has_review:
            pieces += 1
        else:
            missing_review += 1

        if pieces == 4:
            all_four += 1
        elif pieces == 3:
            only_three += 1
        elif pieces == 2:
            only_two += 1
        elif pieces == 1:
            only_one += 1
        else:
            none += 1

    report.say(title)
    report.say("  books checked: " + str(len(isbns)))
    report.say("  all four pieces: " + str(all_four))
    report.say("  three pieces: " + str(only_three))
    report.say("  two pieces: " + str(only_two))
    report.say("  one piece: " + str(only_one))
    report.say("  none: " + str(none))
    report.say("  missing a cover file: " + str(missing_cover))
    report.say("  missing a blurb file: " + str(missing_blurb))
    report.say("  missing a review file: " + str(missing_review))
    report.say("  missing metadata: " + str(missing_metadata))
    report.say("")


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 10. Full coverage versus partial coverage")
    report.say("")
    report.say("The four pieces are metadata, cover page, blurb, and review.")
    report.say("A book has a piece when at least one matching file exists.")
    report.say("Many review files for one ISBN still count as one review piece.")
    report.say("")

    # Keep each source's sets so the overall check can reuse them.
    stored = {}
    combined = set()

    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        metadata = set(records.keys())
        covers = file_isbns(source, "coverpage")
        blurbs = file_isbns(source, "blurb")
        reviews = file_isbns(source, "review")
        stored[source["name"]] = (metadata, covers, blurbs, reviews)
        combined.update(metadata)

        # Per source, I judge the books that source put in metadata.
        describe(report, source["name"], metadata, covers, blurbs, reviews, metadata)

    # Overall: a piece counts if any of the three websites has it.
    all_meta = set()
    all_covers = set()
    all_blurbs = set()
    all_reviews = set()
    for metadata, covers, blurbs, reviews in stored.values():
        all_meta.update(metadata)
        all_covers.update(covers)
        all_blurbs.update(blurbs)
        all_reviews.update(reviews)

    report.say("Overall means the piece exists on at least one website.")
    describe(report, "Overall", combined, all_covers, all_blurbs, all_reviews, all_meta)

    # Also ask a stricter question: the book is complete on every website.
    complete_everywhere = 0
    for isbn in combined:
        good_on_all = True
        for metadata, covers, blurbs, reviews in stored.values():
            if isbn not in metadata or isbn not in covers or isbn not in blurbs or isbn not in reviews:
                good_on_all = False
                break
        if good_on_all:
            complete_everywhere += 1

    report.say("Books with all four pieces on every website: " + str(complete_everywhere))
    report.say("OpenLibrary has no review files, so a book cannot be complete on all three sites.")
    report.save()


if __name__ == "__main__":
    main()
