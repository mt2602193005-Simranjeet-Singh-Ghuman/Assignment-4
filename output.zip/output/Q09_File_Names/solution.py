# Question 9.
# Check that file names follow one pattern, and that the extension matches the folder.
# Expected shape: 9780002171045_c_Amazon_1.jpg
#                 ISBN _ letter _ Website _ number . extension

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


# letter is c, b, or r. Website is one of the three names. The last part is a number.
PATTERN = re.compile(
    r"^(97[89]\d{10})_(c|b|r)_(Goodreads|Amazon|OpenLibrary)_(\d+)\.(jpg|txt)$"
)

# What each folder is supposed to use.
EXPECTED = {
    "coverpage": ("c", "jpg"),
    "blurb": ("b", "txt"),
    "review": ("r", "txt"),
}


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 9. File name and format check")
    report.say("")
    report.say("A consistent name has four parts after the check above:")
    report.say("  ISBN-13, then c/b/r, then the website, then a number, then jpg or txt.")
    report.say("Cover files should be _c_ and .jpg. Blurb and review files should be _b_ or _r_ and .txt.")
    report.say("The website word should match the folder the file is in.")
    report.say("")

    for source in bookdata.SOURCES:
        report.say(source["name"])
        for kind in ("coverpage", "blurb", "review"):
            names = bookdata.list_files(source, kind)
            expect_letter, expect_ext = EXPECTED[kind]
            ok = 0
            broken = []
            wrong_kind = []
            wrong_source = []

            by_isbn, _ = bookdata.index_files(names)
            repeated = 0
            for isbn, group in by_isbn.items():
                if len(group) > 1:  # the same ISBN was saved more than once in this folder
                    repeated += 1

            for name in names:
                match = PATTERN.match(name)
                if match is None:
                    broken.append(name)  # the name does not follow the pattern at all
                    continue

                letter = match.group(2)
                website = match.group(3)
                extension = match.group(5)

                if letter != expect_letter or extension != expect_ext:
                    wrong_kind.append(name)  # a cover saved as txt, or a review letter in the cover folder
                    continue

                if website != source["file_tag"]:
                    wrong_source.append(name)  # pattern is fine, but it names the wrong website
                    continue

                ok += 1  # letter, extension, and website all match this folder

            report.say("  " + kind + ": " + str(len(names)) + " files")
            report.say("    names that match this folder: " + str(ok))
            report.say("    broken names: " + str(len(broken)))
            report.say("    wrong letter or extension: " + str(len(wrong_kind)))
            report.say("    wrong website name in the file: " + str(len(wrong_source)))
            if kind == "review":
                # review_1 and review_2 are two files on purpose. That is not a broken name.
                report.say("    ISBNs with more than one review file: " + str(repeated) + " (expected)")
            else:
                report.say("    ISBNs saved more than once: " + str(repeated))

            if len(wrong_source) > 0:
                filename = source["name"] + "_" + kind + "_wrong_website.txt"
                report.save_lines(filename, wrong_source)
                report.say("    sample: " + wrong_source[0])
                report.say("    full list: " + filename)
            if len(broken) > 0:
                report.say("    broken sample: " + broken[0])
            if len(wrong_kind) > 0:
                report.say("    wrong-kind sample: " + wrong_kind[0])
        report.say("")

    report.say("Goodreads and OpenLibrary cover folders contain files whose names say Amazon.")
    report.say("The extension is still jpg and the letter is still c, but the website word does not match the folder.")
    report.save()


if __name__ == "__main__":
    main()
