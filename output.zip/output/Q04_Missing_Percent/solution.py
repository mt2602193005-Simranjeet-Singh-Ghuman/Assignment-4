# Question 4.
# For each source, what percent of records are missing
# title, authors, publisher, language, date of publication, and genre?

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 4. Percent of missing values, per field and per source")
    report.say("")
    report.say("A value is missing when it is blank or a placeholder: N/A, NA, None, null, or -.")
    report.say("The percent uses every record in that source as the total.")
    report.say("")
    report.say("Source        Field                    Missing     Total    Percent")

    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        total = len(records)  # the denominator for this website

        for label, key in bookdata.ASKED_FIELDS:
            missing = 0
            for record in records.values():
                # A missing key is missing. An empty or N/A value is missing too.
                if key not in record or bookdata.is_missing(record.get(key)):
                    missing += 1

            percent = (missing / total) * 100  # missing records out of all records
            report.say(
                source["name"].ljust(13)
                + label.ljust(25)
                + str(missing).rjust(8)
                + str(total).rjust(10)
                + "{:9.2f}%".format(percent)
            )
        report.say("")

    report.say("Date of publication is the publication_date field. Genre is the genres field.")
    report.save()


if __name__ == "__main__":
    main()
