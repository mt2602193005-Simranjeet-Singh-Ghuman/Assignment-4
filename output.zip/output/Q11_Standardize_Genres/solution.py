# Question 11.
# Make genre labels agree across the three sources.
# "sci-fi", "science-fiction", and "Science Fiction" should become one label.

import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


# Only labels that are the same genre written a different way.
# I do not merge history with historical fiction. Those are different genres.
ALIASES = {
    "sci fi": "science fiction",
    "scifi": "science fiction",
    "sciencefiction": "science fiction",
    "sf": "science fiction",
    "ya": "young adult",
    "non fiction": "nonfiction",
    "childrens fiction": "children fiction",
    "juvenile fiction": "children fiction",
    "mystery and detective": "mystery",
    "mystery and detective stories": "mystery",
    "detective and mystery stories": "mystery",
}


def standardize_label(token):
    # Lower case so Fiction and fiction meet.
    text = token.lower()

    # "&" and the word "and" should not create two labels.
    text = text.replace("&", " and ")

    # children's and childrens should meet. science-fiction and science fiction should meet.
    text = text.replace("'", "")
    text = text.replace("-", " ")
    text = text.replace("_", " ")
    text = text.replace(".", "")  # N.Y. stays one token instead of becoming "n y"

    # Drop other punctuation, but keep letters, numbers, spaces, and +.
    # Keeping + stops C and C++ from becoming the same label.
    kept = []
    for character in text:
        if character.isalnum() or character == " " or character == "+":
            kept.append(character)
        else:
            kept.append(" ")
    text = " ".join("".join(kept).split())

    # Apply the small list of known aliases after the cleanup.
    if text in ALIASES:
        return ALIASES[text]
    return text


def labels_in_record(record):
    # The genres field is one comma-separated string. N/A means this book has no genre.
    raw = record.get("genres")
    if bookdata.is_missing(raw) or not isinstance(raw, str):
        return []

    seen = []
    for part in raw.split(","):
        label = standardize_label(part)
        if label == "":
            continue
        if label not in seen:  # the same label can be written twice in one record
            seen.append(label)
    return seen


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 11. Standardized genre labels")
    report.say("")
    report.say("Steps for one label: lower case, turn & into and, drop apostrophes,")
    report.say("turn hyphens into spaces, then apply a short alias list.")
    report.say("")
    report.say("Checks on the examples from the question:")
    for example in ("sci-fi", "science-fiction", "Science Fiction", "YA", "Children's fiction", "Fiction"):
        report.say("  " + example + "  ->  " + standardize_label(example))
    report.say("")

    # raw spelling -> the set of standard labels it became (should be one)
    # standard label -> the raw spellings that landed on it
    spellings = defaultdict(set)
    raw_unique = set()
    standard_unique = set()

    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        for record in records.values():
            raw = record.get("genres")
            if bookdata.is_missing(raw) or not isinstance(raw, str):
                continue
            for part in raw.split(","):
                original = part.strip()
                if original == "" or bookdata.is_missing(original):
                    continue
                standard = standardize_label(original)
                if standard == "":
                    continue
                raw_unique.add(original)
                standard_unique.add(standard)
                spellings[standard].add(original)

    report.say("Different raw spellings, across all three sources: " + str(len(raw_unique)))
    report.say("Labels left after standardization: " + str(len(standard_unique)))
    report.say("Spellings removed by merging: " + str(len(raw_unique) - len(standard_unique)))
    report.say("")
    report.say("Labels that had more than one spelling (first 20):")

    merged = []
    for standard, originals in spellings.items():
        if len(originals) > 1:
            merged.append((len(originals), standard, sorted(originals)))
    merged.sort(reverse=True)

    lines = []
    for count, standard, originals in merged:
        line = standard + "  <=  " + " | ".join(originals)
        lines.append(line)
    report.save_lines("merged_spellings.txt", lines)

    shown = 0
    for _count, standard, originals in merged:
        if shown == 20:
            break
        # Keep the screen line short. The text file has every spelling.
        preview = " | ".join(originals[:4])
        if len(originals) > 4:
            preview += " | ..."
        report.say("  " + standard + "  <=  " + preview)
        shown += 1

    report.say("")
    report.say("Full merge list: merged_spellings.txt")
    report.say("I did not merge history with historical fiction. Those are different genres.")
    report.say("I also left the word general alone. OpenLibrary often adds it, and it is not a spelling of another genre.")
    report.save()


if __name__ == "__main__":
    main()
