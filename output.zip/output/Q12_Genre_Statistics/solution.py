# Question 12.
# After the labels are standardized:
#   how many genres are there, and what are they
#   how many books does each genre have
#   which genre is the majority class, and which is the minority class
#   plot the genre co-occurrence curve

import importlib.util
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata

import matplotlib

matplotlib.use("Agg")  # save the picture to a file, do not open a window
import matplotlib.pyplot as plt


def load_genre_rules():
    # Question 11 owns the cleaning rules. I load that file so I do not copy them.
    path = ROOT / "output" / "Q11_Standardize_Genres" / "solution.py"
    spec = importlib.util.spec_from_file_location("genre_rules", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)
    rules = load_genre_rules()

    report.say("Question 12. Statistics for the standardized genres")
    report.say("")
    report.say("One sample is one ISBN. If Amazon and Goodreads both say fiction,")
    report.say("that book adds one to fiction, not two.")
    report.say("")

    # isbn -> set of standardized labels from every source that had a genre
    by_book = {}
    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        for isbn, record in records.items():
            labels = rules.labels_in_record(record)
            if isbn not in by_book:
                by_book[isbn] = set()
            for label in labels:
                by_book[isbn].add(label)

    genre_counts = Counter()
    pair_counts = Counter()
    books_with_genre = 0
    books_without_genre = 0

    for labels in by_book.values():
        if len(labels) == 0:
            books_without_genre += 1
            continue
        books_with_genre += 1
        ordered = sorted(labels)  # a fixed order so (fiction, history) is not also (history, fiction)
        for label in ordered:
            genre_counts[label] += 1  # this book is one sample of this genre
        for left in range(len(ordered)):
            for right in range(left + 1, len(ordered)):
                pair = ordered[left] + " + " + ordered[right]
                pair_counts[pair] += 1  # both labels are on this same book

    report.say("Books in the combined set: " + str(len(by_book)))
    report.say("Books with at least one genre: " + str(books_with_genre))
    report.say("Books with no genre on any source: " + str(books_without_genre))
    report.say("Unique genres: " + str(len(genre_counts)))
    report.say("")

    ranking = genre_counts.most_common()  # largest count first
    majority_name, majority_count = ranking[0]
    smallest = ranking[-1][1]
    minority = []
    for name, count in ranking:
        if count == smallest:
            minority.append(name)

    report.say("Majority class: " + majority_name + " (" + str(majority_count) + " books)")
    report.say(
        "Minority class: "
        + str(len(minority))
        + " genres tied at "
        + str(smallest)
        + " book"
    )
    report.say("  examples: " + ", ".join(minority[:8]))
    report.say("")
    report.say("Top 15 genres by number of books:")

    count_lines = []
    name_lines = []
    for name, count in ranking:
        count_lines.append(name + "\t" + str(count))
        name_lines.append(name)
    report.save_lines("genre_counts.txt", count_lines)
    report.save_lines("unique_genres.txt", name_lines)
    report.save_lines("minority_genres.txt", minority)

    for name, count in ranking[:15]:
        report.say("  " + str(count).rjust(5) + "  " + name)

    report.say("")
    report.say("Full genre list: unique_genres.txt")
    report.say("Full counts: genre_counts.txt")
    report.say("")

    # Co-occurrence curve: pairs sorted from the most common shared pair downward.
    pair_ranking = pair_counts.most_common()
    report.say("Genre pairs that appear together on at least one book: " + str(len(pair_ranking)))
    if len(pair_ranking) > 0:
        top_pair, top_pair_count = pair_ranking[0]
        once = 0
        for _pair, count in pair_ranking:
            if count == 1:
                once += 1
        report.say("Most common pair: " + top_pair + " (" + str(top_pair_count) + " books)")
        report.say("Pairs that co-occur only once: " + str(once))
        report.say("")
        report.say("Top 10 co-occurring pairs:")
        for pair, count in pair_ranking[:10]:
            report.say("  " + str(count).rjust(5) + "  " + pair)

    # The full curve falls off immediately. A second panel shows the first 40 pairs,
    # so the drop at the start can actually be read.
    figure, axes = plt.subplots(1, 2, figsize=(11, 4.6))

    ranks = list(range(1, len(pair_ranking) + 1))
    heights = [count for _pair, count in pair_ranking]
    axes[0].plot(ranks, heights, color="#1F4E79", linewidth=1.2)
    axes[0].set_title("All pairs")
    axes[0].set_xlabel("Pair rank")
    axes[0].set_ylabel("Number of books")
    axes[0].grid(True, linestyle="--", alpha=0.4)

    head = pair_ranking[:40]
    axes[1].plot(
        list(range(1, len(head) + 1)),
        [count for _pair, count in head],
        color="#1F4E79",
        marker="o",
        linewidth=1.4,
        markersize=3,
    )
    axes[1].set_title("First 40 pairs")
    axes[1].set_xlabel("Pair rank")
    axes[1].set_ylabel("Number of books")
    axes[1].grid(True, linestyle="--", alpha=0.4)

    figure.suptitle("Genre-wise co-occurrence curve")
    figure.tight_layout()

    picture = Path(__file__).resolve().parent / "genre_cooccurrence.png"
    figure.savefig(picture, dpi=140)
    plt.close(figure)

    report.say("")
    report.say("Plot saved as genre_cooccurrence.png")
    report.say("The left plot is every pair. It drops at once, because most pairs share one book.")
    report.say("The right plot is the first 40 pairs, so that drop can be read.")
    report.save()


if __name__ == "__main__":
    main()
