# Question 1.
# Load the three datasets and report how many records each source has.
# This is the raw size, before any cleaning.

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]  # Assignment 4 folder, two levels above this file
sys.path.insert(0, str(ROOT))

import bookdata  # the shared reader for the three websites


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 1. Records in each source")
    report.say("")
    report.say("I opened the metadata JSON for Goodreads, Amazon, and OpenLibrary.")
    report.say("Each ISBN-13 key is one book, so the number of keys is the number of records.")
    report.say("")

    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)  # the whole dictionary for this website
        count = len(records)  # one key, one record
        report.say(source["name"] + ": " + str(count) + " records")

    report.say("")
    report.say("These counts are the raw sizes. I have not dropped blanks or duplicates yet.")
    report.save()


if __name__ == "__main__":
    main()
