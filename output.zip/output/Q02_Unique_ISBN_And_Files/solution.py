# Question 2.
# How many different ISBN-13 numbers are there across the three sources?
# And how many files sit in coverpage, blurb, and review for each source?

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 2. Unique ISBN-13 numbers, and files in each folder")
    report.say("")

    # Put every ISBN from every website into one set.
    # A set keeps each number once, even if all three sites have it.
    combined = set()
    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        for isbn in records:
            combined.add(isbn)

    report.say("Unique ISBN-13 numbers across all three sources: " + str(len(combined)))
    report.say("I used a set, so an ISBN that appears on more than one site is counted once.")
    report.say("")
    report.say("File counts. I counted real files only. A hidden .gitkeep is not a review.")
    report.say("")
    report.say("Source         coverpage     blurb    review")

    for source in bookdata.SOURCES:
        cover_names = bookdata.list_files(source, "coverpage")
        blurb_names = bookdata.list_files(source, "blurb")
        review_names = bookdata.list_files(source, "review")

        # The question asks for files, not unique books.
        # Two cover files can still belong to one ISBN, so I also print the unique count.
        cover_books, _ = bookdata.index_files(cover_names)
        blurb_books, _ = bookdata.index_files(blurb_names)
        review_books, _ = bookdata.index_files(review_names)

        report.say(
            source["name"].ljust(14)
            + str(len(cover_names)).rjust(10)
            + str(len(blurb_names)).rjust(10)
            + str(len(review_names)).rjust(10)
        )
        report.say(
            "  unique ISBN  "
            + str(len(cover_books)).rjust(10)
            + str(len(blurb_books)).rjust(10)
            + str(len(review_books)).rjust(10)
        )

    report.say("")
    report.say("OpenLibrary reviews has no review text. The folder only holds a hidden .gitkeep, which I skipped.")
    report.say("The file row is what the question asks for. The unique row is there because one book can have many review files.")
    report.save()


if __name__ == "__main__":
    main()
