# Question 3.
# Look for the same ISBN-13 saved more than once inside one source.
# json.load keeps the last copy if a key is repeated, so I also scan the raw text.

import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


# A key in the file looks like "9780395312612":
KEY_PATTERN = re.compile(r'"(97[89]\d{10})"\s*:')


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 3. Duplicate ISBN-13 entries inside each source")
    report.say("")
    report.say("Python's JSON reader would hide a repeated key, so I search the raw file text.")
    report.say("I also check the isbn13 value stored inside each record.")
    report.say("")

    for source in bookdata.SOURCES:
        path = bookdata.metadata_file(source)
        text = path.read_text(encoding="utf-8")  # the file as it was saved, before parsing
        keys = KEY_PATTERN.findall(text)  # every ISBN used as a dictionary key
        key_counts = Counter(keys)
        repeated_keys = []
        for isbn, count in key_counts.items():
            if count > 1:  # the same key was written more than once
                repeated_keys.append(isbn + " x" + str(count))

        records = bookdata.load_metadata(source)
        inner_counts = Counter()
        mismatch = 0
        for isbn, record in records.items():
            inner = str(record.get("isbn13", "")).strip()
            inner_counts[inner] += 1  # the ISBN written inside the record
            if inner != isbn:  # the key and the stored ISBN should be the same book
                mismatch += 1

        repeated_inner = []
        for isbn, count in inner_counts.items():
            if count > 1:
                repeated_inner.append(isbn + " x" + str(count))

        report.say(source["name"])
        report.say("  ISBN keys in the file: " + str(len(keys)))
        report.say("  unique keys: " + str(len(key_counts)))
        report.say("  keys repeated in the raw file: " + str(len(repeated_keys)))
        report.say("  isbn13 values repeated inside records: " + str(len(repeated_inner)))
        report.say("  records whose isbn13 does not match the key: " + str(mismatch))
        if len(repeated_keys) > 0:
            report.say("  repeated keys: " + ", ".join(repeated_keys[:10]))
        report.say("")

    report.say("No source saved the same ISBN-13 twice. Each book appears once in its metadata file.")
    report.save()


if __name__ == "__main__":
    main()
