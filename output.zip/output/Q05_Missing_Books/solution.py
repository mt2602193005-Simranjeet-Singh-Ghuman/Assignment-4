# Question 5.
# Which books are missing from a source completely,
# compared with the combined set of ISBN-13 numbers?

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 5. Books completely missing from each source")
    report.say("")
    report.say("The combined book set is every ISBN that appears in at least one metadata file.")
    report.say("A book is completely missing from a source when that ISBN is not a key in that source.")
    report.say("This check is about metadata. A missing cover file is handled in question 7.")
    report.say("")

    by_source = {}
    combined = set()
    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        isbns = set(records.keys())  # books this website actually stored
        by_source[source["name"]] = isbns
        combined.update(isbns)  # grow the combined set

    report.say("Combined book set: " + str(len(combined)) + " ISBN-13 numbers")
    report.say("")

    any_missing = False
    for source in bookdata.SOURCES:
        missing = sorted(combined - by_source[source["name"]])  # in the union, not in this source
        report.say(source["name"] + " is missing " + str(len(missing)) + " books")
        if len(missing) == 0:
            report.say("  Every ISBN in the combined set is present.")
        else:
            any_missing = True
            report.save_lines(source["name"] + "_missing_isbns.txt", missing)
            report.say("  Full list written to " + source["name"] + "_missing_isbns.txt")
            report.say("  First few: " + ", ".join(missing[:8]))
        report.say("")

    if not any_missing:
        report.say("No source failed to collect a book that another source has.")
        report.say("The gaps in this dataset are empty fields and missing files, not missing ISBNs.")

    report.save()


if __name__ == "__main__":
    main()
