# Question 8.
# Find files in coverpage, blurb, or review whose ISBN
# is not in that source's metadata. Those files are orphans.

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

import bookdata


def main():
    report = bookdata.Report(Path(__file__).resolve().parent)

    report.say("Question 8. Orphan files")
    report.say("")
    report.say("An orphan is a file that does not belong to any ISBN in that source's metadata.")
    report.say("A file with no ISBN in the name is an orphan too.")
    report.say("An odd file name that still starts with a known ISBN is not an orphan.")
    report.say("Those odd names are checked in question 9.")
    report.say("")

    total_orphans = 0
    for source in bookdata.SOURCES:
        records = bookdata.load_metadata(source)
        known = set(records.keys())
        report.say(source["name"])

        for kind in ("coverpage", "blurb", "review"):
            names = bookdata.list_files(source, kind)
            by_isbn, broken = bookdata.index_files(names)

            orphan_isbns = sorted(set(by_isbn.keys()) - known)  # file ISBN, not in the JSON
            orphan_names = []
            for isbn in orphan_isbns:
                for name in by_isbn[isbn]:
                    orphan_names.append(name)
            orphan_names.extend(broken)  # names that do not even contain an ISBN

            total_orphans += len(orphan_names)
            report.say(
                "  "
                + kind
                + ": "
                + str(len(orphan_names))
                + " orphan files ("
                + str(len(orphan_isbns))
                + " unknown ISBNs, "
                + str(len(broken))
                + " names with no ISBN)"
            )
            if len(orphan_names) > 0:
                filename = source["name"] + "_orphan_" + kind + ".txt"
                report.save_lines(filename, orphan_names)
                report.say("    full list: " + filename)
                report.say("    sample: " + ", ".join(orphan_names[:5]))
        report.say("")

    if total_orphans == 0:
        report.say("No orphan files. Every cover, blurb, and review name points at an ISBN in that source's metadata.")

    report.save()


if __name__ == "__main__":
    main()
